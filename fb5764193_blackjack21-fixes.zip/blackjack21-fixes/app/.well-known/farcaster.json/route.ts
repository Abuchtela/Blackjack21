import { NextResponse } from 'next/server';
import { minikitConfig } from '../../../minikit.config';

export async function GET() {
  const ROOT_URL = process.env.ROOT_URL || process.env.NEXT_PUBLIC_BASE_URL || 'http://localhost:3000';

  return NextResponse.json({
    accountAssociation: {
      // Fill this in after running `npx @farcaster/create-mini-app` or via Warpcast developer tools
      header: '',
      payload: '',
      signature: '',
    },
    frame: {
      version: '1',
      name: minikitConfig.miniapp.name,
      iconUrl: `${ROOT_URL}/blue-icon.png`,
      splashImageUrl: `${ROOT_URL}/blue-hero.png`,
      splashBackgroundColor: '#0052FF',
      homeUrl: ROOT_URL,
      webhookUrl: `${ROOT_URL}/api/webhook`,
    },
  });
}
