import type { Metadata } from 'next';
import './globals.css';
import { WalletProvider } from '../components/WalletProvider';

const BASE_URL = process.env.NEXT_PUBLIC_BASE_URL || 'http://localhost:3000';

export const metadata: Metadata = {
  title: 'Blackjack21 — Play on Base',
  description:
    'Classic Blackjack card game with Base wallet integration and Farcaster Frame support. Bet chips, hit or stand, win on Base.',
  openGraph: {
    title: 'Blackjack21 — Play on Base',
    description: 'Play Blackjack on Base Network with Farcaster Frame support.',
    images: [`${BASE_URL}/api/og?action=start`],
  },
  other: {
    // Farcaster Frame v2 (Mini App)
    'fc:frame': JSON.stringify({
      version: 'next',
      imageUrl: `${BASE_URL}/api/og?action=start`,
      button: {
        title: '🃏 Play Blackjack21',
        action: {
          type: 'launch_frame',
          name: 'Blackjack21',
          url: BASE_URL,
          splashImageUrl: `${BASE_URL}/blue-hero.png`,
          splashBackgroundColor: '#0052FF',
        },
      },
    }),
    // Legacy Frame v1 support (for older Farcaster clients)
    'fc:frame:legacy': 'vNext',
    'fc:frame:image': `${BASE_URL}/api/og?action=start`,
    'fc:frame:button:1': '🃏 Play Blackjack',
    'fc:frame:post_url': `${BASE_URL}/api/frame`,
  },
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body className="font-sans">
        <WalletProvider>
          <div className="min-h-screen bg-gradient-to-b from-base-dark to-black">
            {children}
          </div>
        </WalletProvider>
      </body>
    </html>
  );
}
