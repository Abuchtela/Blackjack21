import { NextApiRequest, NextApiResponse } from 'next';
import {
  initializeGame,
  startNewRound,
  playerHit,
  playerStand,
  dealerPlay,
} from '../../lib/gameLogic';
import { GameState } from '../../types/game';

const BASE_URL = process.env.NEXT_PUBLIC_BASE_URL || 'http://localhost:3000';

function encodeState(state: GameState): string {
  // Strip the deck to reduce size — we re-create it when needed
  const slim = {
    playerHand: state.playerHand,
    dealerHand: state.dealerHand,
    gameStatus: state.gameStatus,
    playerScore: state.playerScore,
    dealerScore: state.dealerScore,
    bet: state.bet,
    balance: state.balance,
    result: state.result,
    message: state.message,
    // Store remaining deck length so we can reshuffle if needed
    deckSize: state.deck.length,
  };
  return Buffer.from(JSON.stringify(slim)).toString('base64url');
}

function decodeState(encoded: string): GameState | null {
  try {
    const slim = JSON.parse(Buffer.from(encoded, 'base64url').toString('utf8'));
    // Rebuild a fresh deck for continued play (deck is shuffled, so this is fine)
    const { createDeck } = require('../../lib/gameLogic');
    return {
      ...slim,
      deck: createDeck(),
    } as GameState;
  } catch {
    return null;
  }
}

function frameHtml(imageUrl: string, buttons: string[], postUrl: string): string {
  const buttonMeta = buttons
    .map((label, i) => `<meta property="fc:frame:button:${i + 1}" content="${label}" />`)
    .join('\n        ');

  return `<!DOCTYPE html>
<html>
  <head>
    <meta property="fc:frame" content="vNext" />
    <meta property="fc:frame:image" content="${imageUrl}" />
    <meta property="fc:frame:image:aspect_ratio" content="1.91:1" />
    ${buttonMeta}
    <meta property="fc:frame:post_url" content="${postUrl}" />
    <meta property="og:image" content="${imageUrl}" />
    <meta property="og:title" content="Blackjack21 on Base" />
    <title>Blackjack21</title>
  </head>
  <body><h1>Blackjack21 - Play on Base</h1></body>
</html>`;
}

export default function handler(req: NextApiRequest, res: NextApiResponse) {
  if (req.method !== 'POST') {
    return res.status(405).json({ error: 'Method not allowed' });
  }

  const { untrustedData } = req.body || {};
  const buttonIndex: number = untrustedData?.buttonIndex ?? 1;

  // Decode existing state from query param (if any)
  const encodedState = req.query.state as string | undefined;
  let gameState: GameState = encodedState
    ? decodeState(encodedState) ?? initializeGame()
    : initializeGame();

  // ── State machine ──────────────────────────────────────────────────

  if (gameState.gameStatus === 'betting') {
    // Only button is "Deal" — place default bet of 10 and start round
    const bet = Math.min(10, gameState.balance);
    gameState = startNewRound(gameState, bet);
  } else if (gameState.gameStatus === 'playing') {
    if (buttonIndex === 1) {
      // Hit
      gameState = playerHit(gameState);
      // If it became dealer-turn, resolve immediately
      if (gameState.gameStatus === 'dealer-turn') {
        gameState = dealerPlay(gameState);
      }
    } else if (buttonIndex === 2) {
      // Stand
      gameState = playerStand(gameState);
      gameState = dealerPlay(gameState);
    }
  } else if (gameState.gameStatus === 'finished') {
    // Any button → new round (keep balance)
    if (gameState.balance <= 0) {
      // Out of chips — full reset
      gameState = initializeGame();
    } else {
      gameState = initializeGame(gameState.balance);
    }
  } else if (gameState.gameStatus === 'dealer-turn') {
    gameState = dealerPlay(gameState);
  }

  // ── Build response ─────────────────────────────────────────────────

  const stateParam = encodeState(gameState);
  const postUrl = `${BASE_URL}/api/frame?state=${stateParam}`;

  let buttons: string[];
  let action: string;

  switch (gameState.gameStatus) {
    case 'betting':
      buttons = ['🃏 Deal (Bet 10)'];
      action = 'betting';
      break;
    case 'playing':
      buttons = ['👆 Hit', '✋ Stand'];
      action = 'playing';
      break;
    case 'finished':
      buttons = [
        gameState.balance <= 0 ? '🔄 New Game (Reset)' : '🔄 Play Again',
      ];
      action = gameState.result ?? 'finished';
      break;
    default:
      buttons = ['▶️ Continue'];
      action = 'start';
  }

  // Pass relevant display data to OG image
  const playerCards = gameState.playerHand.map(c => `${c.rank}${c.suit[0].toUpperCase()}`).join(',');
  const dealerCards = gameState.dealerHand.map(c => `${c.rank}${c.suit[0].toUpperCase()}`).join(',');
  const imageUrl =
    `${BASE_URL}/api/og` +
    `?action=${action}` +
    `&ps=${gameState.playerScore}` +
    `&ds=${gameState.gameStatus === 'playing' ? '?' : gameState.dealerScore}` +
    `&pc=${encodeURIComponent(playerCards)}` +
    `&dc=${encodeURIComponent(dealerCards)}` +
    `&bal=${gameState.balance}` +
    `&bet=${gameState.bet}` +
    `&msg=${encodeURIComponent(gameState.message)}`;

  res.setHeader('Content-Type', 'text/html');
  res.status(200).send(frameHtml(imageUrl, buttons, postUrl));
}
