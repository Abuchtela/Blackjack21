import { NextApiRequest, NextApiResponse } from 'next';

// ── Helpers ────────────────────────────────────────────────────────────────────

const SUIT_SYMBOLS: Record<string, string> = {
  H: '♥', D: '♦', C: '♣', S: '♠',
};
const RED_SUITS = new Set(['H', 'D']);

function cardColor(card: string): string {
  const suit = card.slice(-1);
  return RED_SUITS.has(suit) ? '#E53E3E' : '#1A202C';
}

function renderCard(x: number, y: number, card: string, hidden = false): string {
  if (hidden) {
    return `
      <rect x="${x}" y="${y}" width="52" height="72" rx="6" fill="#0052FF" stroke="#3B82F6" stroke-width="1.5"/>
      <text x="${x + 26}" y="${y + 42}" font-family="Arial" font-size="22" font-weight="bold"
            text-anchor="middle" fill="white">?</text>`;
  }
  const rank = card.slice(0, -1);
  const suit = card.slice(-1);
  const symbol = SUIT_SYMBOLS[suit] ?? suit;
  const color = cardColor(card);
  return `
    <rect x="${x}" y="${y}" width="52" height="72" rx="6" fill="white" stroke="#CBD5E0" stroke-width="1.5"
          filter="url(#shadow)"/>
    <text x="${x + 6}" y="${y + 18}" font-family="Arial" font-size="14" font-weight="bold" fill="${color}">${rank}</text>
    <text x="${x + 26}" y="${y + 48}" font-family="Arial" font-size="26" text-anchor="middle" fill="${color}">${symbol}</text>`;
}

function renderHand(cards: string[], startX: number, y: number, hideSecond = false): string {
  return cards
    .map((card, i) => renderCard(startX + i * 60, y, card, hideSecond && i === 1))
    .join('');
}

function resultColor(action: string): string {
  if (action === 'win' || action === 'blackjack') return '#48BB78';
  if (action === 'lose') return '#FC8181';
  if (action === 'push') return '#F6E05E';
  return '#FFFFFF';
}

function resultEmoji(action: string): string {
  if (action === 'blackjack') return '🃏 Blackjack!';
  if (action === 'win') return '🎉 You Win!';
  if (action === 'lose') return '😞 You Lose';
  if (action === 'push') return '🤝 Push';
  return '';
}

// ── Handler ────────────────────────────────────────────────────────────────────

export default function handler(req: NextApiRequest, res: NextApiResponse) {
  const {
    action = 'start',
    ps = '0',       // player score
    ds = '?',       // dealer score (? when hidden)
    pc = '',        // player cards e.g. "AH,KS"
    dc = '',        // dealer cards
    bal = '1000',   // balance
    bet = '0',      // current bet
    msg = '',       // message
  } = req.query as Record<string, string>;

  const playerCards = pc ? pc.split(',').filter(Boolean) : [];
  const dealerCards = dc ? dc.split(',').filter(Boolean) : [];
  const isPlaying = action === 'playing';
  const isFinished = ['win', 'lose', 'push', 'blackjack'].includes(action);
  const isBetting = action === 'betting' || action === 'start';

  const svg = `
<svg width="1200" height="630" xmlns="http://www.w3.org/2000/svg">
  <defs>
    <linearGradient id="bg" x1="0%" y1="0%" x2="100%" y2="100%">
      <stop offset="0%" style="stop-color:#0D1117"/>
      <stop offset="100%" style="stop-color:#161B22"/>
    </linearGradient>
    <linearGradient id="table" x1="0%" y1="0%" x2="0%" y2="100%">
      <stop offset="0%" style="stop-color:#145A32"/>
      <stop offset="100%" style="stop-color:#0B3D23"/>
    </linearGradient>
    <filter id="shadow" x="-10%" y="-10%" width="120%" height="130%">
      <feDropShadow dx="1" dy="2" stdDeviation="3" flood-color="rgba(0,0,0,0.4)"/>
    </filter>
    <filter id="glow">
      <feGaussianBlur stdDeviation="3" result="coloredBlur"/>
      <feMerge><feMergeNode in="coloredBlur"/><feMergeNode in="SourceGraphic"/></feMerge>
    </filter>
  </defs>

  <!-- Background -->
  <rect width="1200" height="630" fill="url(#bg)"/>

  <!-- Felt table -->
  <ellipse cx="600" cy="340" rx="560" ry="270" fill="url(#table)" opacity="0.9"/>
  <ellipse cx="600" cy="340" rx="540" ry="250" fill="none" stroke="#1A7A44" stroke-width="3" opacity="0.6"/>

  <!-- Header -->
  <circle cx="72" cy="52" r="36" fill="#0052FF" filter="url(#glow)"/>
  <text x="72" y="58" font-family="Arial" font-size="20" font-weight="bold"
        text-anchor="middle" fill="white">B21</text>
  <text x="124" y="44" font-family="Arial, sans-serif" font-size="34" font-weight="bold" fill="white">Blackjack</text>
  <text x="124" y="72" font-family="Arial, sans-serif" font-size="18" fill="#8B949E">on Base Network</text>

  <!-- Stats bar -->
  <rect x="860" y="20" width="320" height="64" rx="10" fill="rgba(0,0,0,0.4)"/>
  <text x="880" y="46" font-family="Arial" font-size="16" fill="#8B949E">Balance</text>
  <text x="880" y="68" font-family="Arial" font-size="22" font-weight="bold" fill="#48BB78">${bal} chips</text>
  ${Number(bet) > 0 ? `
  <text x="1020" y="46" font-family="Arial" font-size="16" fill="#8B949E">Bet</text>
  <text x="1020" y="68" font-family="Arial" font-size="22" font-weight="bold" fill="#F6E05E">${bet} chips</text>
  ` : ''}

  ${isBetting ? `
  <!-- Splash / betting state -->
  <text x="600" y="260" font-family="Arial" font-size="72" font-weight="bold"
        text-anchor="middle" fill="white" filter="url(#shadow)">🃏</text>
  <text x="600" y="340" font-family="Arial" font-size="52" font-weight="bold"
        text-anchor="middle" fill="white">Blackjack 21</text>
  <text x="600" y="395" font-family="Arial" font-size="26"
        text-anchor="middle" fill="#8B949E">Place your bet to start playing</text>
  <rect x="420" y="430" width="360" height="56" rx="28" fill="#0052FF"/>
  <text x="600" y="465" font-family="Arial" font-size="22" font-weight="bold"
        text-anchor="middle" fill="white">▶ Deal (Bet 10 chips)</text>
  ` : `
  <!-- Dealer section -->
  <text x="100" y="145" font-family="Arial" font-size="20" font-weight="bold" fill="#8B949E">DEALER</text>
  <text x="100" y="170" font-family="Arial" font-size="28" font-weight="bold" fill="white">Score: ${ds}</text>
  ${renderHand(dealerCards, 100, 185, isPlaying)}

  <!-- Divider -->
  <line x1="80" y1="290" x2="1120" y2="290" stroke="rgba(255,255,255,0.1)" stroke-width="1"/>

  <!-- Player section -->
  <text x="100" y="335" font-family="Arial" font-size="20" font-weight="bold" fill="#8B949E">YOU</text>
  <text x="100" y="360" font-family="Arial" font-size="28" font-weight="bold" fill="white">Score: ${ps}</text>
  ${renderHand(playerCards, 100, 375)}

  <!-- Message / result -->
  ${msg ? `
  <text x="600" y="530" font-family="Arial" font-size="28" font-weight="bold"
        text-anchor="middle" fill="${isFinished ? resultColor(action) : 'white'}"
        filter="${isFinished ? 'url(#glow)' : 'none'}">
    ${isFinished ? resultEmoji(action) + ' — ' : ''}${decodeURIComponent(msg)}
  </text>
  ` : ''}
  `}
</svg>`;

  res.setHeader('Content-Type', 'image/svg+xml');
  res.setHeader('Cache-Control', 'no-cache, no-store');
  res.status(200).send(svg);
}
