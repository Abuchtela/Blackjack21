# Blackjack21 — What Was Fixed

## Files to replace in your repo

### 1. `pages/api/frame.ts` ← **CORE FIX**
The old frame was completely stateless — clicking Hit/Stand just swapped a static image.
Now the frame encodes the full game state (player hand, dealer hand, scores, balance, bet)
as a base64url string in the POST URL query param. Each action runs the real `gameLogic.ts`
functions and passes updated state forward. The game actually plays now.

**How it works:**
- Frame POST → decode state from `?state=` query param → run game action → encode new state → embed in next `post_url`
- No Redis, no database — state lives in the URL. Works perfectly on Vercel serverless.
- Dealer resolves immediately on Stand/bust (no extra round trip needed).

### 2. `pages/api/og.ts` ← **CORE FIX**
Old OG images were 100% hardcoded — always showed the same fake cards and scores.
Now they render the actual game state:
- Real card values passed as query params (`?pc=AH,KS&dc=10S,7D`)
- Dealer's second card is hidden (shown as ?) during play
- Score, balance, bet all display real values
- Result screen shows win/lose/push/blackjack with correct color coding
- Beautiful dark + green felt table design

### 3. `app/layout.tsx` ← **FRAME META FIX**
- Updated to Farcaster Frame v2 (`fc:frame` as JSON with `launch_frame` action)
- Kept v1 legacy tags for older clients
- OG image now points to the dynamic `/api/og` endpoint

### 4. `app/.well-known/farcaster.json/route.ts` ← **MINIAPP FIX**
- Now pulls config from `minikit.config.ts` properly
- Has placeholder for `accountAssociation` — you need to fill this in after
  verifying your domain with Warpcast (Developer Tools → Domains)

## One thing left to do: Domain Verification

To make the Mini App installable on Farcaster:
1. Deploy to Vercel with your domain
2. Go to Warpcast → Settings → Developer → Frames → Add Domain
3. It will give you a `accountAssociation` object
4. Paste it into `app/.well-known/farcaster.json/route.ts`

## Environment Variables needed on Vercel
```
NEXT_PUBLIC_WALLET_CONNECT_PROJECT_ID=your_id_from_cloud.walletconnect.com
NEXT_PUBLIC_BASE_URL=https://your-vercel-url.vercel.app
ROOT_URL=https://your-vercel-url.vercel.app
```
